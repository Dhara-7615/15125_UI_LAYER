﻿CREATE TABLE dbo.Medi (
Id int PRIMARY KEY  NOT NULL,
MedicineNAME VARCHAR(20) ,
Brand VARCHAR(20),
Price int
)﻿



INSERT INTO Medi VALUES (1,'Dolo650','Alpha',20)
INSERT INTO Medi VALUES (2,'Crocin','Alpha',50)
