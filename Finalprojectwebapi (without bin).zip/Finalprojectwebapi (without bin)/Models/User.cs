﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Finalprojectwebapi.Models
{
    public partial class User
    {
        public int Id { get; set; }
        public string Username { get; set; }
        public string Userpassword { get; set; }
    }
}
