import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError, retry } from 'rxjs/operators';
import { Medicine } from './medicine/medicine.model';
import { Devices } from './devices/devices.model';

@Injectable({
  providedIn: 'root'
})
export class ApiserviceService {

  constructor(private http:HttpClient) { }
    // connnect frontend to backend of website

    medicineUrl = "https://localhost:44358/api/Medicines";
    deviceUrl = "https://localhost:44358/api/Devices";


    // get all data

    getAllDeviceData():Observable<any>
    {
       return this.http.get(this.deviceUrl);
    }
  
  getAllMedicineData():Observable<any>
    {
       return this.http.get(this.medicineUrl);
    }
  }

