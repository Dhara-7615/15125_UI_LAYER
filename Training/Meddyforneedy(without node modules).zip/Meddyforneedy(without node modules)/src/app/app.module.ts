import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FooterComponent } from './footer/footer.component';
import { HeaderComponent } from './header/header.component';
import { SectiononeComponent } from './section1/section1.component';
import { SectiontwoComponent } from './section2/sectiontwo.component';
import { SectionthreeComponent } from './sectionthree/sectionthree.component';
import { MedicineComponent } from './medicine/medicine.component';
import { DevicesComponent } from './devices/devices.component';
import { HomeComponent } from './home/home.component';
import { RouterModule,Routes } from '@angular/router';

import { CheckoutComponent } from './checkout/checkout.component';
import{HttpClientModule} from '@angular/common/http';
import { ApiserviceService } from './apiservice.service';

import { FormsModule } from '@angular/forms';

import { LabtestComponent } from './labtest/labtest.component';
import { BagComponent } from './bag/bag.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';


const appRoutes : Routes =[
  {path : '' , component:HomeComponent},
  {path :'Medicine',component:MedicineComponent},
  {path:'Devices',component:DevicesComponent},
  {path :'Login' ,component:LoginComponent},
  {path:'Checkout',component:CheckoutComponent},
  {path:'Bag',component:BagComponent},
  {path:'Labtest',component:LabtestComponent},
  {path:'register',component:RegisterComponent},
 
]
@NgModule({
  declarations: [
    HeaderComponent,
    AppComponent,
    SectiononeComponent,
    SectiontwoComponent,
    FooterComponent,
    SectionthreeComponent,
    MedicineComponent,
    DevicesComponent,
    HomeComponent,
    
    CheckoutComponent,
    
    LabtestComponent,
    BagComponent,
    LoginComponent,
    RegisterComponent,

    
    
],
exports: [RouterModule],
  imports: [
    BrowserModule,
    AppRoutingModule,
    RouterModule.forRoot(appRoutes),
    HttpClientModule,
    FormsModule
   
  ],
  
  providers: [ApiserviceService],
  bootstrap: [AppComponent]
})
export class AppModule { }
