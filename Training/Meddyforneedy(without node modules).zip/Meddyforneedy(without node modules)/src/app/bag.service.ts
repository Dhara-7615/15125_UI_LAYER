import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Bag } from './bag/bag.model';

@Injectable({
  providedIn: 'root'
})
export class BagService {

  constructor(private http:HttpClient) { }
  bagUrl = "https://localhost:44358/api/Carts";
  getAll():Observable<any>
    {
       return this.http.get<Bag>(this.bagUrl);
    }

    headers={
      headers: new HttpHeaders({
          'Content-Type': 'application/json'
      })
  }
    addToBag(bag :Bag):Observable<object>{
     // const headers = {'contentType':'application/json'}
      const body=JSON.stringify(bag);
      console.log(body)
      return this.http.post(this.bagUrl,body,this.headers)
    }
    Delete(Id:any):Observable<object>{
      return this.http.delete(this.bagUrl+"/"+Id,this.headers)
    }
}
