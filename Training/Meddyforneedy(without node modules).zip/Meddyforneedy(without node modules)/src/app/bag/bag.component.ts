import { Component, OnInit } from '@angular/core';
import { BagService } from '../bag.service';
import { Bag } from './bag.model';

@Component({
  selector: 'app-bag',
  templateUrl: './bag.component.html',
  styleUrls: ['./bag.component.css']
})
export class BagComponent implements OnInit {
  bagitems:Bag[] =[];
  constructor(private ser :BagService) { }

  ngOnInit(): void {
   this.getAllBagitems();
  }
  getAllBagitems(){
    this.ser.getAll().subscribe((res)=>{
      console.log("Checking getAllBagitems() method response======>",res);
      this.bagitems = res;
      
      this.grandTotal();
    })
  }
  DeleteItem(bagitem :Bag){
    console.log(bagitem.id);
    this.ser.Delete(bagitem.id).subscribe((data) => {
      console.log("Delete");
      this.getAllBagitems();
    })
   
  }
    finalTotal :Number =0;
 
  grandTotal(){
    for( var i = 0;i<this.bagitems.length;i++){
       this.finalTotal= this.finalTotal+this.bagitems[i].total;
    }
  }

}
