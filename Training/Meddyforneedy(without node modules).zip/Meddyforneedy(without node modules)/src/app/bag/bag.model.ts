export class Bag{
    public id!: number;
    public productName :string;
    public quantity :number;
    public price :any;
    public total :any;
    public imagepath:string;
   
    constructor(Name:string,price:number,Quantity :number,total :number,imagepath:string){
        
        this.productName = Name;
        this.quantity = Quantity;
        this.price = price;
        this.total=total;
        this.imagepath =imagepath;
      
    }




}