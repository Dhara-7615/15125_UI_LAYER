import { Component, OnInit } from '@angular/core';

import { Devices } from './devices.model';
import { ApiserviceService } from '../apiservice.service';
import { Bag } from '../bag/bag.model';
import { BagService } from '../bag.service';

@Component({
  selector: 'app-devices',
  templateUrl: './devices.component.html',
  styleUrls: ['./devices.component.css']
})
export class DevicesComponent implements OnInit {
   ddata :Devices[] =[]
  constructor(private bagService :BagService,private service :ApiserviceService) { }
  // ddata :any =[];
  ngOnInit(): void {
   
    this.service.getAllDeviceData().subscribe((res1)=>{
    console.log(" checking response of getAllDevicedata() method===>",res1);
    this.ddata = res1;
   
    
  })

  }
  addToBag(price : number ,Name:string , quantity: any,path:string){
    
    const total = price*quantity;
    const bagitem =new Bag(Name,price,quantity,total,path);
   
    console.log("Checking MediComponent.addToCart() for cartitem "+bagitem);
    this.bagService.addToBag(bagitem).subscribe((data) => {
     console.log("addtocart===>",data);
     
   })
  }

}
