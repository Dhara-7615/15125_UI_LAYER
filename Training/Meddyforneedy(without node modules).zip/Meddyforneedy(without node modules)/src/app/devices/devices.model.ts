export class Devices{
    public deviceName :string;
    public brand:string;
    public price :any;
    public imagepath:string;
  
    constructor(Name:string,brand :string,price:number,imagepath:string){
        this.deviceName = Name;
        this.brand = brand;
        this.price = price;
        this.imagepath = imagepath;
        

    }




}