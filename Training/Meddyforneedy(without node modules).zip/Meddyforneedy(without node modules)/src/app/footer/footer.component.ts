import { Component } from "@angular/core";

@Component({
    selector:"app-Footer",
    templateUrl:"./Footer.component.html",
    styleUrls: ['./Footer.component.css']

})
export class FooterComponent{

}