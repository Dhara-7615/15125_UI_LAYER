import { Component, OnInit } from '@angular/core';
import { HeaderComponent } from '../header/header.component';
import { SectiononeComponent } from '../section1/section1.component';
import { SectiontwoComponent } from '../section2/sectiontwo.component';
import { SectionthreeComponent } from '../sectionthree/sectionthree.component';
import { FooterComponent } from '../footer/footer.component';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
