import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Users } from './login/login.model';

@Injectable({
  providedIn: 'root'
})
export class LoginService {

  constructor(private http : HttpClient ) { }
  loginUrl="https://localhost:44358/api/Users";
   
  getAllData():Observable<any>
    {
       return this.http.get(this.loginUrl);
    }
  getuser(name :string,password:string) :Observable<any>
  {
      return this.http.get(this.loginUrl+"/"+name+"/"+password)
  }
  
  headers={
    headers: new HttpHeaders({
        'Content-Type': 'application/json'
    })
}
  addToUser(user :Users):Observable<object>{
  
     const body=JSON.stringify(user);
     console.log(body)
     return this.http.post(this.loginUrl,body,this.headers)
   }
}
