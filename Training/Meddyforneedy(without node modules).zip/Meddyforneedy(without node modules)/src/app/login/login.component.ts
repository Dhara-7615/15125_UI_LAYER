import { Component, OnInit } from '@angular/core';
import { LoginService } from '../login.service';
import { Users } from './login.model';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  Users :Users[]=[];
  isValidUser: boolean = false;
  constructor(private loginService :LoginService) { }

  ngOnInit(): void {
    this.loginService.getAllData().subscribe((res)=>{
      console.log("Checking conneticity with database==>",res);
      
       this.Users= res;
      
      
     })
  }
  VerifyUser(name :string ,password:string){
    console.log(name,password);
    this.loginService.getuser(name,password).subscribe((data) => {
      this.isValidUser=true;
      console.log("verified");
      
    },error=>{alert("wrong user")});
    
  }

}
