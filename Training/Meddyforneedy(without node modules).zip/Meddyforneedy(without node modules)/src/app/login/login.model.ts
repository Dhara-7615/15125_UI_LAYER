export class Users{
    public UserName :string;
    public Userpassword:string;
     
     
      constructor(Name:string,password:string){
        
          this.UserName = Name;
          this.Userpassword = password;
          
          
      }
      }