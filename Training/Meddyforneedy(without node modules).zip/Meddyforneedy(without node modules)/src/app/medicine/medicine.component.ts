import { Component, OnInit } from '@angular/core';

import { Medicine } from './medicine.model';
import { ApiserviceService } from '../apiservice.service';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { FooterComponent } from '../footer/footer.component';
import { Bag } from '../bag/bag.model';
import { BagService } from '../bag.service';

@Component({
  selector: 'app-medicine',
  templateUrl: './medicine.component.html',
  styleUrls: ['./medicine.component.css'],
  providers:[BagService,ApiserviceService]
})
export class MedicineComponent implements OnInit {
  medicines: Medicine[] = []
 
  

  constructor(private bagServics:BagService ,private ser :ApiserviceService) { }

   
  ngOnInit(): void {
   
    this.ser.getAllMedicineData().subscribe((res)=>{
      console.log("medicine===>",res);
      this.medicines = res;
    
    })
  }
  addToBag(price : number ,Name:string , quantity: any,path:string){
    
    const total = price*quantity;
    const bagitem =new Bag(Name,price,quantity,total,path);
   
    console.log("Checking MediComponent.addToCart() for cartitem "+bagitem);
    this.bagServics.addToBag(bagitem).subscribe((data) => {
     console.log("addtocart===>",data);
     
   })
  }
}
