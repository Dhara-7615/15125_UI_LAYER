export class Medicine{
    public medicineName :string;
    public packaginingSize:string;
    public price :any;
    public imagepath:string;
   
    constructor(Name:string,size :string,price:number,imagepath:string){
        this.medicineName = Name;
        this.packaginingSize = size;
        this.price = price;
        this.imagepath = imagepath;
        

    }




}