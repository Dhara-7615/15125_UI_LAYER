import { Component, OnInit } from '@angular/core';
import { LoginService } from '../login.service';
import { Users } from '../login/login.model';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  registrationSuceessful: boolean = false;
  constructor(private registerUserService:LoginService) { }

  ngOnInit(): void {
  }
  addUser(name:string,password:string){
    const newUser= new Users(name,password);
    console.log("Checking registerComponent.adduser()===> "+newUser);
    this.registerUserService.addToUser(newUser).subscribe((data) => {
    console.log("Userdata===>",data);
    this.registrationSuceessful=true;
     
   })
  }

}
