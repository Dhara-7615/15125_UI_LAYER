import { Component } from "@angular/core";


@Component({
    selector:"app-Sectionone",
    templateUrl:"./Sectionone.component.html",
    styleUrls: ['./Section1.component.css']

})
export class SectiononeComponent{
     messagedisplay(){
         alert("Thank You For Subscribing to our News Letter!");
     }
}