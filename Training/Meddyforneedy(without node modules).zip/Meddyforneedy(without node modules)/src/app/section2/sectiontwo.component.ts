import { Component } from "@angular/core";


@Component({
    selector:"app-Sectiontwo",
    templateUrl:"./Sectiontwo.component.html",
    styleUrls: ['./Sectiontwo.component.css']

})
export class SectiontwoComponent{

}