import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sectionthree',
  templateUrl: './sectionthree.component.html',
  styleUrls: ['./sectionthree.component.css']
})
export class SectionthreeComponent implements OnInit {

  constructor() {
    
   }

  ngOnInit(): void {
  }

}
